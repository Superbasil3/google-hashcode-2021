import numpy as np
import time
from read import read_file, write_file
from tabulate import tabulate
from compute_score import compute_score
import os


# There is 3 sorts that are nice to test :
# to_start_before, this is the date to start before to be able to have the maximum points.
# average_point_per_days, this is the nbr of point / days that the project requite, may need to compute one with also how many ressources there is
# average_point_per_days_and_contributor
# maybe also the average or min of skill level ?
def sort_project(projects, print_list):
    sorted_projects = sorted(projects, key=lambda k: (k['to_start_before'], -k['average_point_per_days_and_contributor']))
    if print_list:
        header = sorted_projects[0].keys()
        rows = [x.values() for x in sorted_projects]
        print(tabulate(rows, header))
    return sorted_projects


def increase_skill_contributor(contributor, skill_name, skill_level):
    print("Contributor " + contributor['name'] + "increase skill : " + skill_name)
    print(contributor['skills'])
    if skill_name in contributor['skills'] and contributor['skills'][skill_name] <= skill_level:
        contributor['skills'][skill_name] = int(contributor['skills'][skill_name]) + 1
    elif skill_name not in contributor['skills']:
        contributor['skills'][skill_name] = 1
    print("After increase : ")
    print(contributor['skills'])


def look_for_worst_contributor(skill_name, skill_level, contributors):
    list_possible_contributor = []
    for contributor in contributors:
        if skill_name not in contributor['skills'] or contributor['skills'][skill_name] < skill_level:
            compute_value_contributor(contributor)
            list_possible_contributor.append(contributor)
    if len(list_possible_contributor) == 0:
        return None
    else:
        list_possible_contributor_sorted = sorted(list_possible_contributor, key=lambda k: (k['average_skill_level']))
        best_candidate = list_possible_contributor_sorted[0]
        contributors.remove(best_candidate)
        return best_candidate


#to be able to select the bext contributor we want, we need to have some input, like to filter on the number of skill he has, the min, average, etc
def compute_value_contributor(contributor):
    contributor['nbr_skill'] = len(contributor['skills'])
    contributor['can_mentor'] = 0  # when a user is candidate, we can reset the can_mentor score
    sum_skill_level = 0
    for skill_name, skill_level in contributor['skills'].items():
        sum_skill_level = int(sum_skill_level) + int(skill_level)
    contributor['sum_skill_level'] = sum_skill_level
    contributor['average_skill_level'] = sum_skill_level


def look_for_best_contributor_skill(skill_name, skill_level, contributors, other_skill_needed, print_list):
    list_possible_contributor = []

    for contributor in contributors:
        if skill_name in contributor['skills'] and contributor['skills'][skill_name] >= skill_level:
            # It has the skill necessary for doing the jobs, and now we check if he can mentor as well !
            compute_value_contributor(contributor)
            for other_skill_name, other_skill_level in other_skill_needed.items():
                if other_skill_name != skill_name and other_skill_name in contributor['skills'] and contributor['skills'][other_skill_name] >= other_skill_level:
                    # Success
                    print(contributor['name'] + " can mentor " + other_skill_name)
                    if 'can_mentor' in contributor:
                        contributor['can_mentor'] = contributor['can_mentor'] + 1
            list_possible_contributor.append(contributor)
    if len(list_possible_contributor) == 0:
        return None
    else:
        list_possible_contributor_sorted = sorted(list_possible_contributor, key=lambda k: (k['skills'][skill_name], -k['can_mentor'], k['average_skill_level']))
        if print_list:
            header = list_possible_contributor_sorted[0].keys()
        rows = [x.values() for x in list_possible_contributor_sorted]
        print("Skill needed by project : ")
        print(other_skill_needed)
        print("User available")
        print(tabulate(rows, header))
        best_candidate = list_possible_contributor_sorted[0]
        contributors.remove(best_candidate)
        return best_candidate


# tab_file = ["a.txt","b.txt","c.txt","d.txt","e.txt","f.txt"]
tab_file = [
    "a_an_example.in.txt",
#    "b_better_start_small.in.txt",
#    "c_collaboration.in.txt",
#    "d_dense_schedule.in.txt",
#    "e_exceptional_skills.in.txt",
#    "f_find_great_mentors.in.txt"
]
for file in tab_file:
    start_time = time.time()
    input_folder = "input"
    name_file = file
    projects_done = []
    projects_in_progress = []
    contributors, projects_to_do, list_max_skill_needed, max_iteration = read_file(os.path.join(input_folder, name_file))
    projects_sorted = sort_project(projects_to_do, True)

    iteration = 0
    while iteration < max_iteration + 5 or len(projects_in_progress) == 0:

        for project_in_progress in list(projects_in_progress):
            if iteration >= project_in_progress['final_date']:
                # Once a project is finished, we had back the contributor in the available one
                projects_done.append(project_in_progress)
                projects_in_progress.remove(project_in_progress)
                for contributor in project_in_progress['contributors']:
                    contributors.append(contributor)

        for project_sort in list(projects_sorted):
            if project_sort['to_start_before'] > iteration:
                projects_sorted.remove(project_sort)
            else:
                skills_sorted = dict(sorted(project_sort['skills'].items(), key=lambda item: -item[1]))
                project_contributors = []
                possible_contributor_by_skill = {}
                found_all_contributor = True
                skill_to_mentor = {}
                for skill_name, skill_level in skills_sorted.items():
                    best_candidate = None
                    if skill_name in skill_to_mentor:
                        # we can take a bad guy
                        best_candidate_name = look_for_worst_contributor(skill_name, skill_level, contributors)
                    else:
                        best_candidate_name = look_for_best_contributor_skill(skill_name, skill_level, contributors, project_sort['skills'], True)
                    if best_candidate_name is not None:
                        possible_contributor_by_skill[skill_name] = best_candidate_name
                        for contributor_skill_name, contributor_skill_level in best_candidate_name['skills'].items():
                            if contributor_skill_name not in possible_contributor_by_skill and \
                                    contributor_skill_name in skills_sorted and \
                                    contributor_skill_level > skills_sorted[contributor_skill_name] and \
                                    contributor_skill_name not in skill_to_mentor:
                                skill_to_mentor[skill_name] = skill_level
                    else:
                        found_all_contributor = False
                if found_all_contributor:
                    project_contributors = []
                    for skill_name, skill_level in skills_sorted.items():
                        contributor = possible_contributor_by_skill[skill_name]
                        increase_skill_contributor(contributor, skill_name, skill_level)
                        project_contributors.append(contributor)
                    project_sort['final_date'] = int(iteration) + int(project_sort['nbr_days'])
                    project_sort['contributors'] = project_contributors
                    projects_sorted.remove(project_sort)
                    projects_in_progress.append(project_sort)
                else:
                    for contributor in possible_contributor_by_skill.values():
                        contributors.append(contributor)
        iteration = iteration + 1

    write_file(file, projects_done)
#
#
#
#    print("duration algo = ", time.time() - start_time)
#